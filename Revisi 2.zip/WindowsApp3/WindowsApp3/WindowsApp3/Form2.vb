﻿Imports System.Data.OleDb
Imports WindowsApp3.Class1
Public Class Form2
    Dim Conn As OleDbConnection
    Dim Da As OleDbDataAdapter
    Dim Ds As DataSet
    Dim Dr As OleDbDataReader
    Dim LokasiDB As String
    Dim DataSet As New DataTable

    Sub Koneksi()
        LokasiDB = "provider=Microsoft.ACE.OLEDB.12.0; data source=DBLelangAgunan.mdb"
        Conn = New OleDbConnection(LokasiDB)
        If Conn.State = ConnectionState.Closed Then
            Conn.Open()
        End If
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Koneksi()

        Dim queryDetil As New OleDbCommand
        queryDetil.CommandText = "SELECT * FROM table_fotoLokasi Where ID like '%" + NoID + "%'"
        queryDetil.Connection = Conn
        Dr = queryDetil.ExecuteReader
        Dr.Read()


        txtBank.Text = Dr("Bank")
        txtDebitur.Text = Dr("Debitur")
        txtLokasi.Text = Dr("Lokasi")
        txtJenisAgunan.Text = Dr("JenisAgunan")
        txtDokumen.Text = Dr("Dokumen")

    End Sub

    Private Sub MapButton_Click(sender As Object, e As EventArgs) Handles MapButton.Click

        Call Koneksi()
        Dim queryDetil As New OleDbCommand
        queryDetil.CommandText = "SELECT * FROM table_fotoLokasi a, table_lelangagunan b Where b.No like '%" + NoID + "%'"
        queryDetil.Connection = Conn
        Dr = queryDetil.ExecuteReader
        Dr.Read()

        Dim linkurl As String
        linkurl = Dr("Tautan lokasi")
        MapBrowser.Navigate(linkurl.ToString)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Form1.Show()
    End Sub
End Class
