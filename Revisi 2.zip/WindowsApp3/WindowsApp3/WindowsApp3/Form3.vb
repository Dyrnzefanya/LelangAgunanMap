﻿Imports System.Data.OleDb
Imports WindowsApp3.Class1
Public Class Form3
    Dim Conn As OleDbConnection
    Dim Da As OleDbDataAdapter
    Dim Ds As DataSet
    Dim Dr As OleDbDataReader
    Dim LokasiDB As String
    Dim DataSet As New DataTable
    Sub Koneksi()
        LokasiDB = "provider=Microsoft.ACE.OLEDB.12.0; data source=DBLelangAgunan.mdb"
        Conn = New OleDbConnection(LokasiDB)
        If Conn.State = ConnectionState.Closed Then
            Conn.Open()
        End If
    End Sub
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Koneksi()
        Dim queryDetil As New OleDbCommand
        queryDetil.CommandText = "SELECT * FROM table_fotoLokasi a, table_lelangagunan b Where b.No like '%" + NoID + "%'"
        queryDetil.Connection = Conn
        Dr = queryDetil.ExecuteReader
        Dr.Read()

        Dim linkurl As String
        linkurl = Dr("Tautan lokasi")

        Try
            MapShow.Navigate(linkurl.ToString)
        Catch ex As Exception
            MessageBox.Show("Link google map tidak ada di database", "Silahkan cek kembali", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try
    End Sub

End Class