﻿Public Class Class1
    Public Shared NoID
End Class
